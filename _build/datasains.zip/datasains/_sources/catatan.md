## Catatan

#### بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم 



[upload ke github](https://jupyterbook.org/en/stable/start/publish.html) untuk melakukan upload ke github



```{tableofcontents}

```

```{math}
:label: my_label
w_{t+1} = (1 + r_{t+1}) s(w_t) + y_{t+1}
```

```{math}
:label: persamaan3
w_{t+1} = (1 + r_{t+1}) s(w_t) + y_{t+1}
```