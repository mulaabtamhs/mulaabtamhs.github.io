## Welcome to the first my note

#### بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم 



Adalah cita-citaku untuk menyusun sebuah karya yang dapat digunakan dan dimanfaatkan untuk belajar pembelajaran mesin..
Pada catatan ini saya akan membahas secara singkat bagaimana tahapan untuk belajar pembelajarn mesin secara praktis. Tentunya semua materi yang telah dipelajari diharapkan dapat diimplementasikan secara riil. .




\begin{gather*}
a_1=b_1+c_1\\
a_2=b_2+c_2-d_2+e_2
\end{gather*}

\begin{align}
a_{11}& =b_{11}&
  a_{12}& =b_{12}\\
a_{21}& =b_{21}&
  a_{22}& =b_{22}+c_{22}
\end{align}

Check out the content pages bundled with this sample book to see more.

```{tableofcontents}

```

```{math}
:label: my_label
w_{t+1} = (1 + r_{t+1}) s(w_t) + y_{t+1}
```

```{math}
:label: persamaan3
w_{t+1} = (1 + r_{t+1}) s(w_t) + y_{t+1}
```