# sainsdata
Belajar ilmu data lanjut
